# -*- coding: utf-8 -*-


import urlparse
import os
import addon,auth,sections,groups
import movies,tvshows


def get_params():
	paramstring = sys.argv[2]
	
	if paramstring:
		paramstring = paramstring.replace("?",'')
		# params_dict = {'subfolder_id':''}
		temp_dict = urlparse.parse_qs(paramstring)
		for temp_dict_item in temp_dict:
			temp_dict.update({temp_dict_item: ''.join(temp_dict[temp_dict_item])})
		params = temp_dict	
	else:
		params = {}
	return params


def main():
	USER = auth.auth()
	if USER['ID'] > 200000: #валидный айди пользователя
		if USER['ACTIVE'] == 1: #юзер активирован
			if USER['TRY'] == 1:
				print "проверить чтоб текущее время было меньше USER['TRYDATE']"# проверить чтоб текущее время было меньше USER['TRYDATE']
			else:
				if USER['FREEZE'] == 1 and USER['FREE'] != 1:
					xbmc.log('%s: Account is freezed' % _ADDON_NAME, xbmc.LOGNOTICE)	# код счет заморожен
				elif USER['BLOCK'] == 2 and USER['FREE'] != 1:
					xbmc.log('%s: Not enougth money' % _ADDON_NAME, xbmc.LOGNOTICE)	# код недоствточно средств на счету
				elif USER['BLOCK'] == 1 and USER['FREE'] != 1:
					xbmc.log('%s: Not enougth money' % _ADDON_NAME, xbmc.LOGNOTICE)	# код недоствточно средств на счету
				else:
					# Пути к картинкам.
					thumbpath = os.path.join(addon.addon_path, 'resources', 'thumbnails')
					fanart = os.path.join(addon.addon_path, 'fanart.jpg')
					# Получаем параметры вызова плагина.
					params = get_params()
					if params:
						if params['section'] == 'tvshows':
							if 'season_id' in params:
								tvshows.episodes_listing(fanart, thumbpath, params,USER['ID'])
							elif 'tvshow_id' in params:
								tvshows.seasons_listing(fanart,thumbpath, params)
							elif 'group' in params:
								tvshows.listing(fanart,params,USER['ID'])
							else:
								groups.listing(fanart,thumbpath,params,USER)
						else:
							if 'movie_id' in params:
								movies.movie_episodes_list(fanart,params,USER['ID'])
							elif 'collection_id' in params:
								movies.listing(fanart, params,USER['ID'])
							elif 'group' in params:
								if params['group'] == "collections":
									movies.movie_collections_list(fanart,params,USER['ID'])
								else:
									movies.listing(fanart, params,USER['ID'])
							else:
								groups.listing(fanart,thumbpath,params,USER)
					else:
						# Если плагин запущен из XBMC (не рекурсивно), то сначала пишем в лог,
						xbmc.log('%s: Started - Opening Root Sections List' % addon.addon_name, xbmc.LOGNOTICE)
						# а затем выводим список рутовых разделов контента.
						# virtual_folders_list(is_root=True, params=params, fanart=fanart, thumbpath=thumbpath)
						sections.listing(fanart, thumbpath)
		else:			
			xbmc.log('%s: Account is freezed' % _ADDON_NAME, xbmc.LOGNOTICE) # код счет заморожен
	else:
		xbmc.log('%s: Proceed registration' % _ADDON_NAME, xbmc.LOGNOTICE)	#код для проведения пегистрации



if __name__ == '__main__':
	auth.resolve_device()
	main()
