# -*- coding: utf-8 -*-

import sys
import xbmc, xbmcaddon

# Определяем параметры плагина
# global _ADDON_NAME, _addon,_addon_id,_addon_url,_addon_path
addon_name =   'plugin.video.bonus.tv'
addon      =   xbmcaddon.Addon(id=addon_name)
addon_id   =   int(sys.argv[1])
addon_url  =   sys.argv[0]
addon_path =   xbmc.translatePath(addon.getAddonInfo('path')).decode('utf-8')

sections   =  {
								"movies":
									{
										"collection_attr":"c_id",
										"files_attr":"f_id",
										"title":"Кино",
										"thumbnail":"movies.png"
									},
								"tvshows":
									{
										"files_attr":"series_id",
										"title":"Сериалы",
										"thumbnail":"tvshows.png"
									}
							}            