# -*- coding: utf-8 -*-

import xbmc

# Переключаемся на нужный вид в зависимости от текущего скина.
def switch_view():
	skin_used = xbmc.getSkinDir()
	if skin_used == 'skin.confluence':
		xbmc.executebuiltin('Container.SetViewMode(500)') # Вид "Эскизы".
	elif skin_used == 'skin.aeon.nox':
		xbmc.executebuiltin('Container.SetViewMode(512)') # Вид "Инфо-стена"