# -*- coding: utf-8 -*-
import os,re
import xbmc,xbmcgui,xbmcplugin
import addon,pages,videos,requests,skins
from search import runsearch

# Информация по сериалам
# Описание сериала
def getTvshowInfo(section,tvshow_id):
	url = section + "/get_" + section[:-1] + "_description.php"
	values = {"tvshow_id": tvshow_id}
	html = requests.html_req(url, values)
	rutitle = html.find('div',{'class':'rutitle'}).text
	entitle = html.find('div',{'class':'entitle'}).text
	year = html.find('div',{'class':'year'}).text
	rating = int(html.find('div',{'class':re.compile('rating .*')})['class'].replace('rating r', ''))
	country = html.find('div',{'class':'country'}).text
	genre = html.find('div',{'class':'genre'}).text
	description = html.find('div',{'class':'description'}).findChild('div',{'class':'text-block'}).text
	tvshow_info = {'rutitle':rutitle,'entitle':entitle,'year':year,'rating':rating,'country':country,'genre':genre,'description':description}
	return tvshow_info

# Получаем сезоны сериала
def getTvshowSeasons(section,tvshow_id):
	seasons = {}
	url = section + "/get_" + section[:-1] + "_playmenu_seasons.php"
	values = {"tvshow_id": tvshow_id}
	html = requests.html_req(url, values)
	for season in html.findAll('div',{'class':re.compile('item.*')}):
		season_id = season['season_id']
		title = season.findChild('div',{'class':"title"}).text
		seasons.update({season_id:title})
	return seasons

# Получаем эпизоды сезона
def getSeasonEpisodes(section,season_id):
	episodes = {}
	url = section + "/get_" + section[:-1] + "_playmenu_episodes.php"
	values = {"season_id": season_id}
	html = requests.html_req(url, values)
	for episode in html.findAll('div',{'class':re.compile('item.*')}):
		file_id = episode['fl_id']
		title = episode.findChild('div',{'class':"eptitle"}).text
		episodes.update({file_id:title})
	return episodes

# Получаем ссылку на файл серии
def getEpisodeUrl(section,file_id,user_id):
	url = section + "/play.php"
	values = {#"movie_id": movie_id,
						"file_id": file_id,
						"user_id": user_id
						}
	# data = urllib.urlencode(values)				
	# req = urllib2.Request(url, data, REQ_HEADERS)
	# resp = urllib2.urlopen(req)
	# resp = resp.read()
	# resp = postRequest(url, values)
	# xbmc.log(resp)
	# resp = resp.replace("null",'""')
	# resp = resp.replace("\\/",'/')
	# resp = eval(resp)
	html = requests.episode_req(url, values)
	episode_url = html['url']
	return episode_url

# Для сериалов
def listing(fanart,params,user_id):
	listing = []
	is_folder = True #isFolder=True означает, что это папка (виртуальная)
	section = params['section'] 
	group = params['group']
	if group == "search":
		search_str = runsearch()
		tvshows = videos.getSearchResult(section,search_str)
	else:
		tvshows = videos.getVideoList(section,group,user_id)
	xbmc.log('params: %s' % params)
	xbmc.log('tvshows: %s' % tvshows)
	items_range = pages.get_items_range(tvshows,15, params['page'])
	current_page = int(params['page'])
	start = int(items_range['start_item'])
	end = int(items_range['end_item'])
	xbmc.log('current_page: %s' % current_page)
	xbmc.log('start: %s' % start)
	xbmc.log('end: %s' % end)
	thumbpath = os.path.join(addon.addon_path, 'resources', 'thumbnails')
	if not current_page == 1:
		thumb = thumbpath + "/" + section + "-prev.png"
		url = addon.addon_url + '?section=' + section + "&group=" + str(group) + "&page="+ str(current_page - 1)
		list_item = xbmcgui.ListItem(label='PREVIOUS PAGE', thumbnailImage=thumb)
		list_item.setProperty('fanart_image', fanart)
		xbmcplugin.addDirectoryItem(addon.addon_id, url, list_item, isFolder=True)
	video_ids = sorted(tvshows)
	xbmc.log('video_ids full: %s' % video_ids)
	xbmc.log('video_ids: %s' % video_ids[start : end])

	if len(video_ids) > 1:
		video_ids = video_ids[start : end]


	for tvshow in video_ids:
		# thumb= os.path.join(thumbpath, section + ".png")
		# URL, который передается в качестве параметра рекурсивного вызова плагина.
		url = addon.addon_url + '?section=' + section + "&group=" + group + "&tvshow_id=" + str(tvshows[tvshow]['video_id']) + "&thumb_url=" + tvshows[tvshow]['cover_url']

		tvshow_info = getTvshowInfo(section,tvshows[tvshow]['video_id'])
		xbmcplugin.setContent(addon.addon_id,'tvshows')
		# Создаем элемент списка.
		if tvshow_info['entitle']:
			entitle = " (" + tvshow_info['entitle'] + ")"
		else:
			entitle = ''
		list_item = xbmcgui.ListItem(label=tvshow_info['rutitle'] + entitle, thumbnailImage=tvshows[tvshow]['cover_url'])
		# Определяем доп. свойства.
		list_item.setProperty('fanart_image', fanart)
		# list_item.setInfo('video', {
		                  
		#                   })
		# is_folder = True
		listing.append((url, list_item, is_folder))
		# Добавляем элемент в к списку. isFolder=True означает, что это папка (виртуальная).
	xbmcplugin.addDirectoryItems(addon.addon_id,listing,len(listing))
	if not current_page == items_range['pages_count']:
		thumb = thumbpath + "/" + section + "-next.png"
		url = addon.addon_url + '?section=' + section + "&group=" + str(group) + "&page=" + str(current_page + 1)
		list_item = xbmcgui.ListItem(label='NEXT PAGE', thumbnailImage=thumb)
		list_item.setProperty('fanart_image', fanart)
		xbmcplugin.addDirectoryItem(addon.addon_id, url, list_item, isFolder=True)

	
	# Конец списка
	xbmcplugin.endOfDirectory(addon.addon_id)
	skins.switch_view()

def seasons_listing(fanart,thumb, params):
	listing = []
	is_folder = True #isFolder=True означает, что это папка (виртуальная)
	section = params['section']
	group = params['group']
	tvshow = params['tvshow_id']
	thumb = params['thumb_url']
	seasons = getTvshowSeasons(section,tvshow)
	for season in sorted(seasons):
		# URL, который передается в качестве параметра рекурсивного вызова плагина.
		url = addon.addon_url + '?section=' + section + "&group=" + group + "&tvshow_id=" + tvshow + "&season_id=" + season  + "&thumb_url=" + thumb
		# Создаем элемент списка.
		list_item = xbmcgui.ListItem(label=seasons[season], thumbnailImage=thumb)
		# Определяем доп. свойства.
		list_item.setProperty('fanart_image', fanart)
		# is_folder = True
		listing.append((url, list_item, is_folder))
	# Добавляем элемент в к списку. isFolder=True означает, что это папка (виртуальная).
	xbmcplugin.addDirectoryItems(addon.addon_id,listing,len(listing))
	# Конец списка
	xbmcplugin.endOfDirectory(addon.addon_id)

def episodes_listing(fanart, thumb, params,user_id):
	listing = []
	is_folder = False #isFolder=True означает, что это папка (виртуальная)
	section = params['section']
	season_id = params['season_id']
	thumb = params['thumb_url']
	episodes = getSeasonEpisodes(section,season_id)
	xbmcplugin.setContent(addon.addon_id,'episodes')
	for episode in sorted(episodes):
		# URL, который передается в качестве параметра рекурсивного вызова плагина.
		url = getEpisodeUrl(section,episode,user_id)
		# Создаем элемент списка.
		list_item = xbmcgui.ListItem(label=episodes[episode], thumbnailImage=thumb)
		# Определяем доп. свойства.
		list_item.setProperty('fanart_image', fanart)
		listing.append((url, list_item, is_folder))
	# Добавляем элемент в к списку. isFolder=True означает, что это папка (виртуальная).
	xbmcplugin.addDirectoryItems(addon.addon_id,listing,len(listing))
	# Конец списка
	xbmcplugin.endOfDirectory(addon.addon_id)
	skins.switch_view()