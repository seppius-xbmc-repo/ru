# -*- coding: utf-8 -*-
import os,re
import xbmc, xbmcgui, xbmcplugin
import addon,requests,pages,videos, skins
from search import runsearch
# Информация по фильмам
# Описание фильма
def getMovieInfo(section,movie_id):
	url = section + "/" + "get_" + section + "_list_info.php"
	values = {"movie_id": movie_id}
	html = requests.html_req(url, values)
	
	
	# search_str =  rutitle + ' ' + year
	# info = requests.kinopoisk({'search':rutitle})

	
	return html

# Берем берем реальный айди фильма по айдишнику из каталога
def getMovieFileId(section, movie_id, user_id):
	episodes = {}
	url = section + "/get_" + section[:-1] + "_playmenu.php" # делаем из название множественного единственноt
	values = {"movie_id": movie_id,
						"user_id": user_id
						}
	html = requests.html_req(url, values)
	for episode in html.findAll(attrs={'fl_id':True}):
		order_id = episode['abs_id']
		file_id = episode['fl_id']
		title = episode.findChild(attrs={'class':'title'}).text
		title = title.encode('utf-8')
		episodes.update({order_id:{file_id:title}})
	# xbmc.log('episodes dict: %s ' % episodes)
	return episodes

# Берем прямую ссылку на файл фильма
def getMovieUrl(section,episodes, user_id):
	episodes_urls = {}
	# xbmc.log('episodes: %s ' % episodes)
	for episode in episodes:
		# xbmc.log('episode: %s ' % episode)
		file_id = episodes[episode].keys()[0]
		# xbmc.log('file_id: %s ' % file_id)
		url = section + "/play.php"
		# xbmc.log('url: %s ' % url)
		values = {#"movie_id": movie_id,
							"file_id": file_id,
							"user_id": user_id
							}
		html = requests.html_req(url, values)
		episode_url = html.find(attrs={'url':True})['url']
		# xbmc.log('episode_url : %s ' % episode_url)
		title = episodes[episode][file_id]
		# xbmc.log('title : %s ' % title)
		episodes_urls.update({episode:{'url':episode_url, 'title':title}})
	# xbmc.log('episodes_url dict: %s ' % episodes_urls)
	return episodes_urls

	# Для фильмов
def listing(fanart, params,user_id):
	# auth_keys = auth()
	# user_id = auth_keys['id']
	section = params['section']
	group = params['group']
	if group == "search":
		search_str = runsearch()
		movies = videos.getSearchResult(section,search_str)
	elif 'collection_id' in params:
		collection_id = params['collection_id']
		movies = videos.getCollectionVideoList(section, collection_id, user_id)
		group = params['group'] + "&collection_id=" + collection_id
	else:
		movies = videos.getVideoList(section,group,user_id)
	xbmc.log('movies: %s' % movies)
	listing = []
	
	# Для отображения 25 фильмов на страницу
	# movies_len = len(movies)
	# items_per_page = 25
	# if math.fmod(movies_len,items_per_page) == 0:
	# 	pass
	items_range = pages.get_items_range(movies,15, params['page'])
	xbmc.log('items_range: %s' % items_range)
	current_page = int(params['page'])
	xbmc.log('current_page: %s' % current_page)
	start = int(items_range['start_item'])
	end = int(items_range['end_item'])
	thumbpath = os.path.join(addon.addon_path, 'resources', 'thumbnails')

	xbmcplugin.setContent(addon.addon_id,'movies')
	# PREVIOS PAGE ITEM
	if not current_page == 1:
		url = addon.addon_url + '?section=' + section + "&group=" + str(group) + "&page=" + str(current_page - 1)
		thumb = thumbpath + "/" + section + "-prev.png"
		list_item = xbmcgui.ListItem(label='PREVIOUS PAGE', thumbnailImage= thumb)
		list_item.setProperty('fanart_image', fanart)
		xbmcplugin.addDirectoryItem(addon.addon_id, url, list_item, isFolder=True)
	video_ids = sorted(movies)
	xbmc.log('video_ids: %s' % video_ids[start : end])

	if len(video_ids) > 1:
		video_ids = video_ids[start : end]

	for movie in video_ids:
		# file_id = get_file_id(section, item)
		movie_id = movies[movie]['video_id']
		
		html = getMovieInfo(section,movie_id)
		# Создаем элемент списка.
		

		episodes = getMovieFileId(section, movie_id, user_id)
		if len(episodes) > 1:
			is_folder = True
			url = addon.addon_url + '?section=' + section + "&group=" + str(group) + "&movie_id=" + str(movie_id) + "&thumb_url=" + movies[movie]['cover_url']
		else:
			is_folder = False
			episodes_urls = getMovieUrl(section,episodes, user_id)
			url = episodes_urls['1']['url']
		# if not info['alternativeHeadline'][0]:
		# 	entitle = ''
		# else: 
		# 	entitle = " | " + info['alternativeHeadline'][0] 
		list_item = xbmcgui.ListItem(label=html.find('div',{'class':'rutitle'}).text, thumbnailImage=movies[movie]['cover_url'])
		# Определяем доп. свойства.
		list_item.setProperty('fanart_image', fanart)
		list_item.setProperty('IsPlayable', 'true')
		list_item.setInfo('video', {


	# rutitle = html.find('div',{'class':'rutitle'}).text
	# entitle = html.find('div',{'class':'entitle'}).text
	# year = int(html.find('div',{'class':'year'}).text)
	# rating = float(html.find('div',{'class':re.compile('rating .*')})['class'].replace('rating r', ''))
	# country = html.find('div',{'class':'country'}).text
	# genre = html.find('div',{'class':'genre'}).text
	# description = html.find('div',{'class':'description'}).findChild().text
	# movie_info = {'rutitle':rutitle,'entitle':entitle,'year':year,'rating':rating,'country':country,'genre':genre,'description':description}


		                  				'genre': html.find('div',{'class':'genre'}).text,
									'year': int(html.find('div',{'class':'year'}).text),
									'rating' :float(html.find('div',{'class':re.compile('rating .*')})['class'].replace('rating r', '')),
									# 'cast' :info['actors'],
									# 'director': info['director'],
									'plot': html.find('div',{'class':'description'}).findChild().text,
									'title': html.find('div',{'class':'rutitle'}).text,
									'originaltitle': html.find('div',{'class':'entitle'}).text,
									# 'studio': info['company'][0],
									# 'writer': info['story_by'][0],
									# 'premiered': info['world_start'][0]

		                  				# 'title':movie_info['rutitle'],
		                  				# 'originaltitle':movie_info['entitle'],
		                  				# 'plot':movie_info['description'],
		                  				# 'year':movie_info['year'],
		                  				# 'genre': movie_info['genre'], 
		                  				# 'rating':movie_info['rating']
		                  				})
		
		listing.append((url,list_item, is_folder))
		# Добавляем элемент к списку. isFolder=False означает, что это файл для проигрывания.
	xbmcplugin.addDirectoryItems(addon.addon_id,listing,len(listing))

	if not current_page == items_range['pages_count']:
		url = addon.addon_url + '?section=' + section + "&group=" + str(group) + "&page=" + str(current_page + 1)
		thumb = thumbpath + "/" + section + "-next.png"
		list_item = xbmcgui.ListItem(label='NEXT PAGE', thumbnailImage=thumb)
		list_item.setProperty('fanart_image', fanart)
		xbmcplugin.addDirectoryItem(addon.addon_id, url, list_item, isFolder=True)

	# Конец списка.
	xbmcplugin.endOfDirectory(addon.addon_id, updateListing=True)
	# Переключаемся на нужный вид.
	skins.switch_view()


def movie_collections_list(fanart,params,user_id):
	section = params['section']
	listing = []
	is_folder = True
	collections = videos.getCollectionsList(section)
	for collection in sorted(collections):
		thumb = collections[collection]['cover_url']
		title = collections[collection]['collection_title']
		collection_id = collections[collection]['collection_id']
		url = addon.addon_url + '?section=' + section + "&group=collections" + "&collection_id=" + str(collection_id) + "&page=1"
		list_item = xbmcgui.ListItem(label=title, thumbnailImage=thumb)
		list_item.setProperty('fanart_image', fanart)
		listing.append((url,list_item, is_folder))
	# Добавляем элемент к списку. isFolder=False означает, что это файл для проигрывания.
	xbmcplugin.addDirectoryItems(addon.addon_id,listing,len(listing))
	# Конец списка.
	xbmcplugin.endOfDirectory(addon.addon_id)


def movie_episodes_list(fanart,params,user_id):
	section = params['section']
	movie_id = params['movie_id']
	thumb = params['thumb_url']

	listing = []
	is_folder = False

	file_ids = getMovieFileId(section, movie_id,user_id)
	episodes = getMovieUrl(section,file_ids,user_id)
	# xbmc.log('%s episodes dict:' % episodes)
	for episode in sorted(episodes):
		url = episodes[episode]['url']
		title = episodes[episode]['title'].decode('utf-8')
		# xbmc.log('url: %s ' % url)
		list_item = xbmcgui.ListItem(label=episodes[episode]['title'], thumbnailImage=thumb)
		# Определяем доп. свойства.
		list_item.setProperty('fanart_image', fanart)
		list_item.setProperty('IsPlayable', 'true')
		
		listing.append((url,list_item, is_folder))
	# Добавляем элемент к списку. isFolder=False означает, что это файл для проигрывания.
	xbmcplugin.addDirectoryItems(addon.addon_id,listing,len(listing))
	# Конец списка.
	xbmcplugin.endOfDirectory(addon.addon_id)
	# Переключаемся на нужный вид.
	skins.switch_view()