# -*- coding: utf-8 -*-
import os,re
import xbmc,xbmcgui,xbmcplugin
import addon, requests




# Функция для получения подпапок контента
def getGroups(section,USER):
	groups = {}
	url = section + "/get_data.php"
	values = {"user_id": USER['ID'],
						"soho_user": USER['SOHO_USER']
						}
	html = requests.html_req(url, values)

	for group in html.findAll('div', {'id': re.compile("^(%s)-groups-\d"%section)}):
		group_id = int(group['id'].replace(section + '-groups-',''))
		group_name = group.text
		groups.update({group_id: group_name})
	return groups #groups hash



def listing(fanart, thumbpath, params,USER):
	listing = []
	is_folder = True #isFolder=True означает, что это папка (виртуальная)
	section = params['section']
	groups = getGroups(section,USER) #парсим html c группами
	xbmc.log("groups: %s" % groups)
	for group in groups:
		thumb= os.path.join(thumbpath, addon.sections[section]['thumbnail'])
		# URL, который передается в качестве параметра рекурсивного вызова плагина.
		if group == sorted(groups)[-1]:
			url = addon.addon_url + '?section=' + section + "&group=search" + "&page=1"
		elif group == sorted(groups)[0]:
			url = addon.addon_url + '?section=' + section + "&group=collections" + "&page=1"
		else:
			url = addon.addon_url + '?section=' + section + "&group=" + str(group) + "&page=1"
		# Создаем элемент списка.
		list_item = xbmcgui.ListItem(label=groups[group], thumbnailImage=thumb)
		# Определяем доп. свойства.
		list_item.setProperty('fanart_image', fanart)
		# is_folder = True
		listing.append((url, list_item, is_folder))
	# Добавляем элемент в к списку. isFolder=True означает, что это папка (виртуальная).
	xbmcplugin.addDirectoryItems(addon.addon_id,listing,len(listing))
	# Конец списка
	xbmcplugin.endOfDirectory(addon.addon_id)