# -*- coding: utf-8 -*-

import urllib
import urlparse
import urllib2
from BeautifulSoup import BeautifulSoup
try:
	import json
except ImportError:
	import simplejson as json

import sys
reload(sys)
sys.setdefaultencoding('utf-8')




PORTAL_URL          = "http://195.78.244.199/"
REQ_HEADERS         = {'User-Agent':'Mozilla/5.0 (SmartHub; SMART-TV; U; Linux/SmartTV+2014; Maple2012) AppleWebKit/537.42+ (KHTML, like Gecko) SmartTV Safari/537.42+',
												'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'
												}
# _auth_url            = 
# _list_mediafiles_url = "get_data.php"

CURRENT_PLATFORM    = 2014 #просто потому что у меня платформа 2014

def auth_req(serial,mac):
	url = PORTAL_URL + "user_access.php"
	values = {"serial": serial,
						"mac": mac,
						"version": "300",
						"platform": CURRENT_PLATFORM
						}
	data = urllib.urlencode(values)				
	req = urllib2.Request(url, data, REQ_HEADERS)
	resp = urllib2.urlopen(req)
	auth_response = json.load(resp)
	
	return auth_response


# Функция HTTP запроса для парсера
def html_req(url, values):
	url = PORTAL_URL + url
	data = urllib.urlencode(values)				
	req = urllib2.Request(url, data, REQ_HEADERS)
	resp = urllib2.urlopen(req)
	html = resp.read()
	html = BeautifulSoup(html)
	resp.close()
	return html

# Функция HTTP запроса для парсера
def episode_req(url, values):
	url = PORTAL_URL + url
	data = urllib.urlencode(values)				
	req = urllib2.Request(url, data, REQ_HEADERS)
	resp = urllib2.urlopen(req)
	html = resp.read()
	# html = BeautifulSoup(html)
	html = html.replace("null",'""')
	html = html.replace("\\/",'/')
	html = eval(html)
	
	resp.close()
	return html

def kinopoisk(param={}):
	base_url = "http://kparser.pp.ua/json/"
	url = base_url + param.keys()[0] + "/" + param.values()[0] 
	req = urllib2.Request(url)
	resp = urllib2.urlopen(req)
	kp_resp = json.load(resp)
	if 'search' in param:
		for movie in kp_resp['result']:
			if movie['most_wanted'] == 1:
				film = movie['id']
		kp_resp = kinopoisk({'film':film})
	return kp_resp


