# -*- coding: utf-8 -*-
import os
import xbmcplugin,xbmcgui
import addon




def listing(fanart, thumbpath):
	listing = []
	is_folder = True #isFolder=True означает, что это папка (виртуальная)
	sections = addon.sections
	for section in sections.keys():
		thumb= os.path.join(thumbpath, sections[section]['thumbnail'])
		# URL, который передается в качестве параметра рекурсивного вызова плагина.
		url = addon.addon_url + '?section=' + section
		# Создаем элемент списка.
		list_item = xbmcgui.ListItem(label=sections[section]['title'], thumbnailImage=thumb)
		# Определяем доп. свойства.
		list_item.setProperty('fanart_image', fanart)
		# # Добавляем элемент в к списку. isFolder=True означает, что это папка (виртуальная).
		listing.append((url, list_item, is_folder))
	xbmcplugin.addDirectoryItems(addon.addon_id,listing,len(listing))
	# Конец списка
	xbmcplugin.endOfDirectory(addon.addon_id)