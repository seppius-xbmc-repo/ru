# -*- coding: utf-8 -*-
import re
import xbmc
from addon import sections
from requests import html_req

# Функция для получения списка коллекций
def getCollectionsList(section):
	collections = {}
	url = section + "/get_collections_list.php"
	values = {}
	html = html_req(url, values)
	for collection in html.findAll(attrs={sections[section]['collection_attr']:True}):
		order_id = int(collection['abs_id'])
		collection_id = int(collection[sections[section]['collection_attr']])
		collection_title = collection.find("span").text
		cover_url = re.findall('url\((.*?)\)', collection.findChild('div', {'class':'cover'})['style'])[0].replace("\'","")
		collections.update({order_id:{'collection_id':collection_id,'collection_title':collection_title,'cover_url':cover_url}})
	return collections
# Функция для получения списка фильмов из коллекции	
def getCollectionVideoList(section, collection, user_id):
	videos = {}
	url = section + "/get_collection.php"
	values =  {
				"collection_id": collection,
				"user_id": user_id
				}
	html = html_req(url, values)
	for video_item in html.findAll(attrs={sections[section]['files_attr']:True}):
		order_id = int(video_item['abs_id'])
		video_id = int(video_item[sections[section]['files_attr']])
		cover_url = re.findall('url\((.*?)\)', video_item.findChild('div', {'class':'cover'})['style'])[0].replace("\'","")
		videos.update({order_id: {'video_id':video_id, 'cover_url':cover_url}})
	return videos

# Функция для получения списка фильмов
def getVideoList(section, group, user_id):
	videos = {}
	url = section + "/get_" + section + "_list.php"
	values = {"group_id": group,
						"user_id": user_id
						}
	html = html_req(url, values)

	for video_item in html.findAll(attrs={sections[section]['files_attr']:True}):
		order_id = int(video_item['abs_id'])
		video_id = int(video_item[sections[section]['files_attr']])
		cover_url = re.findall('url\((.*?)\)', video_item.findChild('div', {'class':'cover'})['style'])[0].replace("\'","")
		videos.update({order_id: {'video_id':video_id, 'cover_url':cover_url}})
	return videos

def getSearchResult(section,search_str):
	videos = {}
	xbmc.log("search_str: %s" % search_str)
	url = section + "/get_search_results.php"
	values = {"search_type": 1,
						"search_text": search_str
						}
	html = html_req(url, values)
	xbmc.log("html: %s" % html)
	for video_item in html.findAll(attrs={sections[section]['files_attr']:True}):
		order_id = int(video_item['abs_id'])
		video_id = int(video_item[sections[section]['files_attr']])
		cover_url = video_item['image']
		videos.update({order_id: {'video_id':video_id, 'cover_url':cover_url}})
	return videos