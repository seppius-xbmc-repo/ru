# -*- coding: utf-8 -*-

import math

def get_items_range(videos_dict,items_per_page, page):
	list_len = len(videos_dict)
	# items_per_page = 25
	page = int(page)
	start = 0
	end = 0 
	if math.fmod(list_len,items_per_page) == 0.0:
		temp_pages = list_len/items_per_page
	else:
		temp_pages = list_len/items_per_page + 1
	new_list_len = list_len + (temp_pages-2)*2 + 2 #добавляем к списку по одному ярлыку на первую и последнюю страницу и по 2 на остальные
	if math.fmod(new_list_len,items_per_page) == 0.0:
		pages = new_list_len/items_per_page
	else:
		pages = new_list_len/items_per_page + 1

	if page == 1 and pages > 1:
		start = 0
		end = items_per_page - 1
	elif page == pages:
		if pages == 1:
			start = 0
			end = list_len
		elif pages == 2:
			start = (items_per_page - 1) 
			end = list_len -1
		else:
			start = (items_per_page - 1) + (pages - 2)*(items_per_page - 2)
			end = list_len 
	else:
		if page > 2:
			start = (items_per_page - 1) + (page - 2)*(items_per_page - 2)
			end = start  + items_per_page - 2
		else:
			start = (items_per_page)  - 1
			end = start + items_per_page - 2
	items_range = {'pages_count':pages, 'start_item':start, 'end_item':end}
	# xbmc.log('items_range: %s' % items_range)
	return items_range