# -*- coding: utf-8 -*-

# Импортируем нужные нам библиотеки
# import urllib
# import urlparse
# import urllib2
# import time
# import sys
# import os

# try:
# 	import json
# except ImportError:
# 	import simplejson as json


import string
import random

from uuid import getnode as get_mac

# import xbmcaddon




import requests




USER = {'ID':0,
				'IP':0,
				'BALANCE':0,
				'ACTIVE':0,
				'FREE':0,
				'FREEZE':0,
				'BLOCK':0,
				'TRY':0,
				'TRYDATE':0,
				'SOHO_BILLING':0,
				'SOHO_USER':0,
				'GROUPS':''
				}




def resolve_device():

	global serial, mac
	serial = 'JHCNHA5IR42H6'
	mac = '84a466a6f089'
	# serial = _addon.getSetting("auth.serial")

	# mac = _addon.getSetting("auth.mac")
	# serial = uuid.uuid5(uuid.NAMESPACE_DNS, mac).hex[-13:]
	if not serial:
		serial = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(14))
		_addon.setSetting("auth.serial", serial)
	if not mac:
		mac = ''.join(("%012X" % get_mac())[i:i+2] for i in range(0, 12, 2))
		_addon.setSetting("auth.mac", mac)
		_addon.setSetting("auth.generated", 1)

	return serial, mac


def auth():
	auth_response = requests.auth_req(serial,mac)
	if auth_response['id'] <= 200000:
			USER['ID'] = -1
			USER['IP'] = auth_response['ip']
			USER['BALANCE'] = 0
			USER['ACTIVE'] = 0
			USER['FREE'] = 0
			USER['FREEZE'] = 0
			USER['BLOCK'] = 0
			USER['TRY'] = 0
			USER['TRYDATE'] = 0
			USER['SOHO_BILLING'] = 0
			USER['SOHO_USER'] = 0
			USER['GROUPS'] = ''
	else:
			USER['ID'] = auth_response['id']
			USER['IP'] = auth_response['ip']
			USER['BALANCE'] = auth_response['balance']
			USER['ACTIVE'] = int(auth_response['active'])
			USER['FREE'] = auth_response['free']
			USER['FREEZE'] = auth_response['freeze']
			USER['BLOCK'] = auth_response['block']
			USER['TRY'] = auth_response['try']
			USER['TRYDATE'] = auth_response['try_to_date']
			USER['SOHO_BILLING'] = auth_response['soho_billing']
			USER['SOHO_USER'] = auth_response['soho_user']
			USER['GROUPS'] = auth_response['groups']
	return USER





# def authorization_loop(period):
# 	auth(serial, mac)
# 	# threading.Timer(15, printit).start()
# 	# auth(serial, mac)
	
	

