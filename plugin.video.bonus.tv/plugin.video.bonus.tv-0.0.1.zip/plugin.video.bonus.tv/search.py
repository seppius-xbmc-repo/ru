# # -*- coding: utf-8 -*-
import xbmc

# #########################################################
# # Function  : GUIEditExportName                         #
# #########################################################
# # Parameter :                                           #
# #                                                       #
# # name        sugested name for export                  #
# #                                                       #
# # Returns   :                                           #
# #                                                       #
# # name        name of export excluding any extension    #
# #                                                       #
# #########################################################
# def GUIEditExportName(name):

#     exit = True
#     while (exit):
#           kb = xbmc.Keyboard('default', 'heading', True)
#           kb.setDefault(name)
#           kb.setHeading(__language__(33223))
#           kb.setHiddenInput(False)
#           kb.doModal()
#           if (kb.isConfirmed()):
#               name_confirmed  = kb.getText()
#               name_correct = name_confirmed.count(' ')
#               if (name_correct):
#                  GUIInfo(2,__language__(33224))
#               else:
#                    name = name_confirmed
#                    exit = False
#           else:
#               GUIInfo(2,__language__(33225))
#     return(name)
	
# #########################################################

def runsearch():
	search_str = ""
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск по названию')
	skbd.doModal()
	if skbd.isConfirmed():
		search_str = skbd.getText()
	return search_str