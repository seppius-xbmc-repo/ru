﻿# Copyright (c) 2013 Torrent-TV.RU
# Writer (c) 2013, Welicobratov K.A., E-mail: 07pov23@gmail.com

import xbmcgui
import time
import xbmcaddon
import json

import defines

def LogToXBMC(text, type = 1):
    ttext = ''
    if type == 2:
        ttext = 'ERROR:' 
    print '[MenuForm %s] %s %s\r' % (time.strftime('%X'),ttext, text)

class MenuForm(xbmcgui.WindowXMLDialog):
    CMD_ADD_FAVOURITE = 'favourite_add'
    CMD_DEL_FAVOURITE = 'favourite_delete'
    CMD_UP_FAVOURITE = 'favourite_up'
    CMD_DOWN_FAVOURITE = 'favourite_down.php'
    CMD_CLOSE_TS = 'close_ts'
    CONTROL_CMD_LIST = 301
    def __ini__(self, *args, **kwargs):
        self.li = None
        self.get_method = None
        self.session = None
        self.result = 'None'
        pass

    def onInit(self):
        self.result = 'None'
        if not self.li:
            return
        try:
            cmds = self.li.getProperty('commands').split(',')
            list = self.getControl(MenuForm.CONTROL_CMD_LIST)
            list.reset()
            for c in cmds:
                if c == MenuForm.CMD_ADD_FAVOURITE:
                    title = 'Добавить в избранное'
                elif c == MenuForm.CMD_DEL_FAVOURITE:
                    title = 'Удалить из избранного'
                elif c == MenuForm.CMD_UP_FAVOURITE:
                    title = 'Поднять вверх'
                elif c == MenuForm.CMD_DOWN_FAVOURITE:
                    title = 'Опустить вниз'
                elif c == MenuForm.CMD_CLOSE_TS:
                    title = 'Завершить TS'
                list.addItem(xbmcgui.ListItem(title, c))
            list.setHeight(cmds.__len__()*38)
            list.selectItem(0)
            self.setFocusId(MenuForm.CONTROL_CMD_LIST)
            LogToXBMC('Focus Controld %s' % self.getFocusId())
        except Exception, e: 
            LogToXBMC("В списке нет комманд %s" % e)
            pass

    def onClick(self, controlId):
        LogToXBMC('ControlID = %s' % controlId)
        if controlId == MenuForm.CONTROL_CMD_LIST:
            lt = self.getControl(MenuForm.CONTROL_CMD_LIST)
            li = lt.getSelectedItem()
            cmd = li.getLabel2()
            LogToXBMC("cmd=%s" % cmd)
            if cmd == MenuForm.CMD_DEL_FAVOURITE: self.DelFromFavourite()
            elif cmd == MenuForm.CMD_ADD_FAVOURITE: self.AddToFavourite()
            elif cmd == MenuForm.CMD_DOWN_FAVOURITE: self.DownFavourite()
            elif cmd == MenuForm.CMD_UP_FAVOURITE: self.UpFavourite()
            elif cmd == MenuForm.CMD_CLOSE_TS: self.CloseTS()
            self.close()

    def _sendCmd(self, cmd):
        channel_id = self.li.getLabel2()
        res = self.get_method('http://api.torrent-tv.ru/v3/%s?session=%s&channel_id=%s&typeresult=json' % (cmd, self.session, channel_id), cookie = self.session)
        LogToXBMC(res)
        LogToXBMC('http://api.torrent-tv.ru/v3/%s?session=%s&channel_id=%s&typeresult=json' % (cmd, self.session, channel_id))
        jdata = json.loads(res)
        if jdata['success'] == '0':
            self.result = jdata['error']
        else:
            self.result = 'OK'
    def DelFromFavourite(self):
        self._sendCmd('favourite_delete.php')

    def AddToFavourite(self):
        self._sendCmd('favourite_add.php')

    def UpFavourite(self):
        self._sendCmd('favourite_up.php')

    def DownFavourite(self):
        self._sendCmd('favourite_down.php')

    def CloseTS(self):
        LogToXBMC('Closet TS')
        self.result = 'TSCLOSE'

    def GetResult(self):
        if not self.result:
            self.result = 'None'
        res = self.result
        self.result = 'None'
        return res