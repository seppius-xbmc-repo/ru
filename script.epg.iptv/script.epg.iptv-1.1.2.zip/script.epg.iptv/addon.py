# -*- coding: utf-8 -*-
import tvepg
import xmlETR

start = True