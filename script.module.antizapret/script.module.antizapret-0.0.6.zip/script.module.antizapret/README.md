script.module.antizapret
========================

What it is
----------
Library antizapret allows you to send HTTP request through proxy server to avoid site blocking. Library use auto configuration to bypass request through proxy for blocked sites.

Download
--------
Check out the [Releases](https://github.com/afedchin/antizapret/releases) tab to download the ZIP file.

