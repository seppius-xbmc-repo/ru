﻿####################################################################
# Copyright (C) Aleksey S.Galickiy 2015-2016 - All Rights Reserved #
####################################################################

# -*- coding: utf-8 -*-

from urllib import urlopen as udpxy
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import xbmc, xbmcaddon, os, time, socket, urllib2

ADDR = (socket.gethostbyname_ex(socket.gethostname())[2][0], 12067)
TVBOX = 'http://tvbox.link/proxytv3/'
LICENSE = '1234567890'
MAC = '1234:ABCD'
LICMAC = '?license=' + LICENSE + '&mac=' + MAC
NEWPLIST = TVBOX + 'newplist.php' + LICMAC
NEWCHANN = TVBOX + 'udph.php' + LICMAC + '&path='
ID_GA = 'UA-71267915-5'
USER_AGENT_GA = {'User-Agent': 'ProxyTV-3'}
HOST_GA = 'http://www.google-analytics.com/__utm.gif'
PARAMS = HOST_GA + '?utmhn=tvbox.link&utmp=&utmac='+ID_GA+'&utmcc=__utma%3D999.999.999.999.999.1%3B'
USERUTC = 6
BUFFS = 4096

SERVICE_NAME = 'service.proxy.tv3'
SERVICE_START = xbmcaddon.Addon(id=SERVICE_NAME);
SERVICE_PATH = xbmc.translatePath(SERVICE_START.getAddonInfo('path')).decode('utf-8')

class ProxyTVerver(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/octet-stream')
        self.end_headers()
    def do_GET(self):
        path = self.path.lstrip('/')
        while True:
            lstprx = udpxy(NEWCHANN + path).read()
            stream = udpxy(lstprx)
            self.do_HEAD()
            while True:
                data = stream.read(BUFFS)
                if not data:break
                else:self.wfile.write(data)

class ProxyTV3():
    def __init__(self, addr):
        self.localhost = addr[0]
        self.localport = addr[1]
    def run(self):
        self.plist()
        self.ga()
        try:
            server = HTTPServer((self.localhost, self.localport), ProxyTVerver)
            print '\n', time.asctime(), '\nProxyTV3 Starts - %s:%s' % (self.localhost, self.localport), '\n'
            server.serve_forever()
        except KeyboardInterrupt:
            server.socket.close()
    def plist(self):
        fileM3U = open(os.path.join(SERVICE_START.getSetting('folder'), 'proxytv3.m3u'), 'w')
        fileM3U.write('#EXTM3U tvg-autor="Alexey S.Galickiy service.proxy.tv3 for KODI"\n')
        nplist = udpxy(NEWPLIST)
        for line in nplist:
            channelId=line.split('|')
            codeCH = channelId[0]
            idCH = channelId[1]
            chTitle = channelId[2]
            serviceUTC = int(channelId[6])
            noProxy = int(channelId[8])
            group = channelId[9]
            tvgSHIFT = str(USERUTC - serviceUTC)
            tvgLogo = idCH + '.png'
            fileM3U.write('#EXTINF:-1 tvg-shift="' + tvgSHIFT + 
                          '" tvg-id="' + idCH + '" tvg-logo="' + tvgLogo + 
                          '" group-title="' + group + '",' + chTitle + '\n')
            fileM3U.write('http://'+self.localhost+':'+str(self.localport)+'/'+codeCH+'\n')
        fileM3U.close()
    def ga(self):
        try:
            reqGA = urllib2.Request(PARAMS, headers = USER_AGENT_GA)
            opGA = urllib2.urlopen(reqGA)
        except:
            pass
ProxyTV3(ADDR).run()
